
#include <iostream>
#include <string>
#include <climits>
#include <algorithm>
#include "Matrix/Matrix.h"
#include "Simplex.h"
using namespace std;

void printInfo(int iteration, double z, const Matrix& An, const Matrix& B, const Matrix& B_inv, const Matrix& cb, const Matrix& cn, const Matrix& Xb, const Matrix& Rn, 
				const Matrix& db, std::vector<int>& basic, std::vector<int>& nonBasic, double theta, int q, int p) {
	
	cout << "Iteration: " << iteration << endl;
	cout << "Z = " << z << endl;
	
	printVector(basic, "Basic");
	printVector(nonBasic, "Non Basic");
	
	cout << endl << "Matrix An: " << endl;
	An.print();
	
	cout << endl << "Matrix B: " << endl;
	B.print();
	
	cout << endl << "Matrix B_inv: " << endl;
	B_inv.print();
	
	cout << endl << "Matrix cb: " << endl;
	cb.print();
	
	cout << endl << "Matrix cn: " << endl;
	cn.print();
	
	cout << endl << "Matrix Xb: " << endl;
	Matrix::transpose(Xb).print();
	
	cout << "Theta = " << theta;
	cout << "\tq = " << q;
	cout << "\tp = " << p;
	cout << "\tB(p) = " << basic[p] << endl;
	
	cout << "Rn = ";
	Rn.print();

	cout << "db = ";
	Matrix::transpose(db).print();
	
	cout << std::string(50,'-') << endl;
}

void printIteration(const int iteration, const int q, const double rq, const int p, const int Bp, const double theta, const int z, const vector<int>& basic, const vector<int>& nonBasic) {
    cout << "\tIteration " << iteration << ":";
    cout << "\tq = " << q;
    cout << "\trq = " << rq;
    cout << "\tp = " << p;
    cout << "\tB(p) = " << Bp;
    cout << "\tTheta* = " << theta;
    cout << "\tZ = " << z;
    
    int size = basic.size();
    cout << "\tB = {";
    cout << basic[0] << ", ";
    for(int i = 1; i < size; i++)
		cout << basic[i] << (i < size - 1 ? ", " : "}");

	size = nonBasic.size();
	cout << "\tN = {" << basic[0] << ", ";
	for(int i = 1; i < size; i++)
		cout << nonBasic[i] << (i < size - 1 ? ", " : "}");
	cout << endl;
}

void phase_1(const int n, const int m, const Matrix& A, const Matrix& b, Matrix& Xb_1, Matrix& B_inv_1, std::vector<int>& basic_1, std::vector<int>& nonBasic_1, const bool blandsRule, bool& unfeasible) {
	
	Matrix A_1 = A; //Matrix of constrictions of phase 1
	Matrix An_1 = A; //Matrix of non basic variables of phase 1
	B_inv_1 = Matrix::identity(m); //Basic matrix of phase 1
	Matrix B_1 = B_inv_1;
	A_1.insertMatrixInCol(B_inv_1, n);

	Matrix c_1(n + m,1); //Vector of coefficients
	for(int i = 0; i < n; i++)
		c_1.set(i,0,0);
	for(int i = n; i < n + m; i++)
		c_1.set(i,0,1);
	 
	Matrix cb_1(1,m,1);
	Matrix cn_1(1,n);
	
	Xb_1 = b;
	cout << "Initial Xb = ";
	Matrix::transpose(Xb_1).print();
	
	double z = (Matrix::matrixProduct(cb_1,Xb_1)).at(0,0); //Value of objective function
	
	int iteration = 1;
	bool optimal = false;
	bool unlimited = false;
	bool degenerate = false;
	
    cout << "Phase I" << endl;
    
	while(not optimal and not unlimited and not degenerate) {
		
		int q = 0; //Number of variable that will enter next
		int q_index = 0; //Index in nonBasic variables vector of variable that will enter next
		Matrix Rn = computeReducedCosts(cn_1, cb_1, B_inv_1, An_1, nonBasic_1, q, q_index, optimal, blandsRule); //Reduced costs vector
		if(not optimal) {
			Matrix db = computeBasicFeasibleDirection(B_inv_1, A.getMatrixCol(q-1), unlimited); //Basic feasible direction
			if(not unlimited) {
				int p; //Index in base of the variable that will exit
				double theta = computeTheta(db, Xb_1, p); //Step length
                printIteration(iteration++, q, Rn.at(0,q_index), p, basic_1[p], theta, z, basic_1, nonBasic_1);
				updateVariables(z, Xb_1, basic_1, nonBasic_1, theta, db, q, q_index, Rn.at(0,q_index), p);
				updateMatrices(m, A_1, B_1, B_inv_1, An_1, cb_1, cn_1, db, nonBasic_1, q, q_index, p);
				degenerate = isDegenerate(Xb_1);
			}
		}
	}
    
	cout << "\t" << (optimal ? "Optimal" : "Not optimal") << "\t" << (unlimited ? "Unlimited" : "Not unlimited") << "\t" << (degenerate ? "Degenerate" : "No Degenerate") << endl;

	if(z == 0) {
        cout << "\tBasic feasible solution found, iteration " << iteration << endl;
        cout << "\tB = ";
        for(int i : basic_1)
			cout << i << " ";
		cout << "\tN = ";
		for(int i : nonBasic_1)
			cout << i << " ";
		cout << endl;
		unfeasible = false;
	} else
		unfeasible = true;
}

void phase_2(const int n, const int m, const Matrix& A, const Matrix& b, const Matrix& c, Matrix& Xb, Matrix& B_inv, std::vector<int>& basic, std::vector<int>& nonBasic, const bool blandsRule, int exitCode) {
	
	Matrix B = Matrix::inverse(B_inv);
	
	Matrix An(m,1);
	An.replaceCol(A.getCol(nonBasic[0]-1),0);
	for(unsigned int i = 1; i < nonBasic.size(); i++)
		An.insertCol(A.getCol(nonBasic[i]), i);
	
	Matrix cb = Matrix(1,m);
	for(unsigned int i = 0; i < basic.size(); i++)
		cb.set(0, i, c.at(basic[i]-1, 0));
	
	Matrix cn = Matrix(1,n-m);
	for(unsigned int i = 0; i < nonBasic.size(); i++)
		cn.set(0,i, c.at(nonBasic[i]-1, 0));
	
	double z = Matrix::matrixProduct(cb,Xb).at(0,0);
	
	int iteration = 1;
	//CHANGE THIS
	bool optimal = false;
	bool unlimited = false;
	bool degenerate = false;

    cout << "Phase II" << endl;

	while(not optimal and not unlimited and not degenerate) {
		
		int q = 0;
		int q_index = 0;
		Matrix Rn = computeReducedCosts(cn, cb, B_inv, An, nonBasic, q, q_index, optimal, blandsRule);
		if(not optimal) {
			Matrix db = computeBasicFeasibleDirection(B_inv, A.getMatrixCol(q-1), unlimited);
			if(not unlimited) {
				int p;
				double theta = computeTheta(db, Xb, p); 
                printIteration(iteration++, q, Rn.at(0,q_index), p, basic[p], theta, z, basic, nonBasic);
				updateVariables(z, Xb, basic, nonBasic, theta, db, q, q_index, Rn.at(0,q_index), p);
				updateMatrices(m, A, B, B_inv, An, cb, cn, db, nonBasic, q, q_index, p);
				degenerate = isDegenerate(Xb);
			}
		}
	}
    
    
	cout << "\t" << (optimal ? "Optimal" : "Not optimal") << "\t" << (unlimited ? "Unlimited" : "Not unlimited") << "\t" << (degenerate ? "Degenerate" : "No Degenerate") << endl;
    
    if(optimal) {
		exitCode = 0;
        cout << "\tBasic feasible solution found, iteration " << iteration << "\tZ = " << z << endl;
    } else if(unlimited) {
		exitCode = 1;
		cout << "Unlimited problem" << endl;
	} else {
		exitCode = 2;
		cout << "Degenerate problem" << endl;
	}
    
}

extern Matrix computeReducedCosts(const Matrix& cn, const Matrix& cb, const Matrix& B_inv, const Matrix& An, const std::vector<int>& nonBasic, int& q, int& q_index, bool& optimal, const bool blandsRule) {
	
	Matrix RHS = Matrix::matrixProduct(Matrix::matrixProduct(cb, B_inv), An);
	RHS.scalarProduct(-1);
	
	Matrix Rn = Matrix::matrixSum(cn,RHS);
	
	int i_neg = -1;
	int size = Rn.getCols();

	for(int i = 0; i < size and i_neg == -1; i++) //Searches for a negative reduced cost. If it is found, then i_neg = i
		if(Rn.at(0,i) < 0)
			i_neg = i;
	
	if(i_neg == -1) {//Optimal solution
		optimal = true;
		return Rn;
	}
	
	q = nonBasic[i_neg];
	q_index = i_neg;
	
	optimal = false;
	
	if(blandsRule)
		return Rn;
		
	for(int i = q_index + 1; i < size; i++) {
		if(Rn.at(0,i) < Rn.at(0,q_index)) {
			q_index = i;
			q = nonBasic[q_index];
		}
	}
	
	return Rn;
}

extern Matrix computeBasicFeasibleDirection(const Matrix& B_inv, const Matrix& Aq, bool& unlimited) {
	
	unlimited = true;
	
	Matrix db = Matrix::matrixProduct(B_inv, Aq);
	db.scalarProduct(-1);
	
	for(unsigned int i = 0; i < db.getRows() and unlimited; i++)
		if(db.at(i,0) < 0)
			unlimited = false;
	
	return db; //Unlimited problem
}

extern double computeTheta(const Matrix& db, const Matrix& Xb, int& p) {
	
	double min_length = INT_MAX;
	
	for(unsigned int i = 0; i < db.getRows(); i++) {
		if(db.at(i,0) < 0) {
			double length = -(Xb.at(i,0)/db.at(i,0));
			if(length < min_length) {
				p = i;
				min_length = length;
			}
		}
	}
	
	return min_length;
}

extern void updateVariables(double& z, Matrix& Xb, vector<int>& basic, vector<int>& nonBasic, const double theta, const Matrix& db, const int q, const int q_index, const double rq, const int p) {
	
	z = z + theta * rq;
	Xb = Matrix::matrixSum(Xb, Matrix::scalarProduct(db,theta));
	
	Xb.set(p,0,theta);
	
	nonBasic[q_index] = basic[p];
	basic[p] = q; 
}

extern void updateMatrices(int m, const Matrix& A, Matrix& B, Matrix& B_inv, Matrix& An, Matrix& cb, Matrix& cn, const Matrix& db, const vector<int>& nonBasic, const int q, const int q_index, const int p) {
	
    Matrix p_col = A.getMatrixCol(nonBasic[q_index] - 1);
	Matrix q_col = A.getMatrixCol(q-1);
	//Update of An
	An.replaceMatrixCol(p_col, q_index);
	//Update of B
	B.replaceMatrixCol(q_col, p);
	
	/*
	//Update of B_inv
	vector<double> newCol;
	double dbf_p = db.at(p,0);
	for(int i = 0; i < m; i++)
		if(i != p)
			newCol.push_back(-db.at(i,0)/dbf_p); 
		
	newCol.insert(newCol.begin(), -1/dbf_p);
	
	Matrix E = Matrix::identity(m);
	
	cout << "Non Basic: ";
	for(int i : nonBasic)
		cout << i << " ";
	cout << endl;
	
	E.replaceCol(newCol, p);
	cout << "p = " << p << endl;
	
	cout << "db = ";
	Matrix::transpose(db).print();
	
	cout << "E = " << endl;
	E.print();
	*/
//	B_inv = Matrix::matrixProduct(E,B_inv);
	
	
	B_inv = Matrix::inverse(B);
	/*
	cout << "Classical Inverse: " << endl;
	B_inv.print();
	
	cout << endl << "Inverse test: " << endl;
	test.print();*/
	
	
	
	
	
	//Update of cb and cn
	double cb_p = cb.at(0,p);
	cb.set(0,p,cn.at(0,q_index));
	cn.set(0,q_index,cb_p);
}

bool isDegenerate(const Matrix& Xb) {
	
	for(unsigned int i = 0; i < Xb.getRows(); i++)
		if(Xb.at(i,0) == 0)
			return true;
			
	return false;
}

void printVector(std::vector<int> v, std::string name) {
	std::cout << name << ": ";
	for(double i : v)
		std::cout << i << " ";
	std::cout << std::endl;
}





