
#include <vector>
#include <string>
#include "Matrix/Matrix.h"
using namespace std;

extern void printInfo(int iteration, double z, const Matrix& An, const Matrix& B, const Matrix& B_inv, const Matrix& cb, const Matrix& cn, const Matrix& Xb, const Matrix& Rn, 
				const Matrix& db, std::vector<int>& basic, std::vector<int>& nonBasic, double theta, int q, int p);

extern void printIteration(const int iteration, const int q, const double rq, const int p, const int Bp, const double theta, const int z, const vector<int>& basic, const vector<int>& nonBasic);

extern void phase_1(const int n, const int m, const Matrix& A, const Matrix& b, Matrix& Xb, Matrix& B_inv, std::vector<int>& optimalBasic_1, std::vector<int>& optimalNonBasic_1, const bool blandsRule, bool& unfeasible);

extern void phase_2(const int n, const int m, const Matrix& A, const Matrix& b, const Matrix& c, Matrix& Xb, Matrix& B_inv, std::vector<int>& basic, std::vector<int>& nonBasic, const bool blandsRule, int exitCode);

extern Matrix computeReducedCosts(const Matrix& cn, const Matrix& cb, const Matrix& B_inv, const Matrix& An, const std::vector<int>& nonBasic, int& q, int& q_index, bool& optimal, const bool blandsRule);

extern Matrix computeBasicFeasibleDirection(const Matrix& B_inv, const Matrix& Aq, bool& unlimited);

extern double computeTheta(const Matrix& db, const Matrix& Xb, int&);

extern void updateVariables(double& z, Matrix& Xb, std::vector<int>& basic, std::vector<int>& nonBasic, const double step, const Matrix& db, const int q, const int q_index, const double rq, const int p);

extern void updateMatrices(int m, const Matrix& A, Matrix& B, Matrix& B_inv, Matrix& An, Matrix& cb, Matrix& cn, const Matrix& db, const vector<int>& nonBasic, const int q, const int q_index, const int p);
	
extern bool isDegenerate(const Matrix& Xb);

extern void printVector(std::vector<int>, std::string);
