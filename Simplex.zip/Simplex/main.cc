#include <iostream>
#include <vector>
#include "Matrix/Matrix.h"
#include "Simplex.h"
using namespace std;

void read_input(unsigned int&, unsigned int&, Matrix&, Matrix&, Matrix&);
void info(const int, const int, const Matrix&, const Matrix&, const Matrix&);

int main(void) {
	
	unsigned int n;
	unsigned int m;
	Matrix A, An, B_inv;
	Matrix b;
	Matrix c;
	Matrix Xb;
	const bool blandsRule = true;
	
	
	read_input(n,m,A,b,c);
	
	std::vector<int> nonBasic(n);
	for(unsigned int i = 0; i < n; i++)
		nonBasic[i] = i + 1;
	
	std::vector<int> basic(m);
	for(unsigned int i = 0; i < m; i++)
		basic[i] = i + n + 1;
	
	bool unfeasible = false;
    
	phase_1(n, m, A, b, Xb, B_inv, basic, nonBasic, blandsRule, unfeasible);
	
    std::vector<int> non_artificial;
    std::vector<int> nonBasic_2;
    
           
	for(unsigned int i = 0; i < nonBasic.size(); i++) {
    	if(nonBasic[i] <= (int)n) {
            non_artificial.push_back(i+1);
            nonBasic_2.push_back(i+1);
        }
    }
     
	int exitCode = 0;

	phase_2(n, m, A, b, c, Xb, B_inv, basic, nonBasic_2, blandsRule, exitCode);
	
	return 0;
}

void read_input(unsigned int& n, unsigned int& m, Matrix& A, Matrix& b, Matrix& c){
	
	cin >> n >> m;
	A = Matrix(m, n);
	for(unsigned int i = 0; i < m; i++)
		for(unsigned int j = 0; j < n; j++) {
			double x;
			cin >> x;
			A.set(i,j,x);
		}
	
	c = Matrix(n,1);
	for(unsigned int i = 0; i < n; i++) {
		double x;
		cin >> x;
		c.set(i,0,x);
	}
	
	b = Matrix(m,1);
	for(unsigned int i = 0; i < m; i++) {
		double x;
		cin >> x;
		b.set(i,0,x);
	}
}

void info(const int n, const int m, const Matrix& A, const Matrix& b, const Matrix& c) {
	
	cout << "Variables: " << n << endl;
	cout << "Constrictions: " << m << endl;
	
	cout << "A: " << endl;
	A.print();
	
	cout << endl << "B: " << endl;
	Matrix::transpose(b).print();
	
	cout << endl << "C: " << endl;
	Matrix::transpose(c).print();
	
}


