La implementacion en C++ consta de:
	Matrix.h	Matrix.cc	Simplex.h	Simplex.cc	main.cc
	
Comando de compilacion desde el mismo directorio en el que estan los archivos:
	g++ -Wall -O2 Matrix.h Matrix.cc Simplex.h Simplex.cc main.cc

Ejecutar con una entrada determinada con datos en un .txt:
	-Windows: a.exe <nombre_archivo.txt
	-Linux: ./a.out <nombre_archivo.txt
	El .txt debe estar en el mismo directorio que el ejecutable

Para cambiar entre regla de Bland y coste reducido mas negativo:
	Linea 20 del archivo main.cc
	
Entradas del programa:
	-Conjunto de datos 45 (DNI 77127872V):	p1_45.txt	p2_45.txt	p3_45.txt	p4_45.txt
	-Conjunto de datos ?? (DNI ):
	
