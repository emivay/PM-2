#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>
#include <stdio.h>
#include "Matrix.h"
#include "Simplex.h"
using namespace std;

//Imprime la informacion relevante de cada iteracion del simplex
void printIteration(const int iteration, const int q, const double rq, const int p, const int Bp, const double theta, const double z, const vector<int>& basic, const vector<int>& nonBasic) {
	
	printf("%5sIteracion %4d:", "", iteration);
	printf("%5sq = %2d", "", q);
	printf("%5srq = %9.3f", "", rq);
	printf("%5sB(p) = %2d", "", Bp);
	printf("%5sTheta* = %8.3f", "", theta);
	printf("%5sZ = %8.3f\n", "", z);
	
	/*cout << "\tB = ";
	for(unsigned int i = 0; i < basic.size(); i++)
		cout << basic[i] << " ";
	cout << endl;
	
	cout << "\tN = ";
	for(unsigned int i = 0; i < nonBasic.size(); i++)
		cout << nonBasic[i] << " ";
	cout << endl;*/
}

//Realiza una iteracion del simplex a partir de los valores proporcionados
void simplexIteration(int iteration, int n, int m, const Matrix& A, Matrix& An, Matrix& B_inv, Matrix& cn, Matrix& cb, Matrix& Xb, double& z, vector<int>& basic, vector<int>& nonBasic, const bool blandsRule, int& out) {
	
	int q = 0; //Number of variable that will enter next
	int q_index = 0; //Index in nonBasic variables vector of variable that will enter next
	
	bool optimal = false;
	Matrix Rn = computeReducedCosts(cn, cb, B_inv, An, nonBasic, q, q_index, optimal, blandsRule); //Reduced costs vector
	/*if(iteration == 16) {
		printf("%5sRn = ", "");
		for(unsigned int i = 0; i < Rn.getCols(); i++) {
			printf("%18.14f%3s",Rn.at(0,i), "");
			if(i == 4)
				printf("\n%10s","");
		}
		printf("\n");
	}*/
	if(optimal) {
		out = 1;
		return;
	}
	
	bool unlimited = false;
	Matrix db = computeBasicFeasibleDirection(B_inv, A.getMatrixCol(q-1), unlimited); //Basic feasible direction
	if(unlimited) {
		out = 2;
		return;
	}
	
	int p; //Index in base of the variable that will exit
	double theta = computeTheta(db, Xb, p); //Step length
	int Bp = basic[p];
	updateMatrices(m, A, B_inv, An, cb, cn, db, p, Bp, q_index, q);
	updateVariables(z, Xb, basic, nonBasic, theta, db, q, Rn.at(0,q_index), p);
	printIteration(iteration, q, Rn.at(0,q_index), p, Bp, theta, z, basic, nonBasic);
	
	if(isDegenerate(Xb))
		out = 3;
}

//Realiza la fase 1 del simplex
void phase_1(const int n, const int m, const Matrix& A, const Matrix& b, Matrix& Xb_1, Matrix& B_inv_1, vector<int>& basic_1, vector<int>& nonBasic_1, int& iteration, const bool blandsRule, int& out) {
	
	B_inv_1 = Matrix::identity(m); //La 1a inversa es la identidad, de dimension m
	Matrix A_1 = A; //Matriz de coeficientes de variables de la fase 1
	A_1.insertMatrixInCol(B_inv_1, n); //Inserta la matrix identidad (que es la inversa) en la ultima columna de la matriz de coeficientes A, dando la matriz de fase 1 de dimension m x (n + m)
	Matrix An_1 = A; //Matriz de variables no basicas de fase 1, en la primera iteracion, variables desde 1 a n
	
	Matrix c_1(n + m,1); //Matriz columna de coeficientes de variables en la funcion objetivo de la fase 1
	for(int i = 0; i < n; i++)
		c_1.set(i,0,0);	//Los coeficientes de las variables 1 a n son 0
	for(int i = n; i < n + m; i++)
		c_1.set(i,0,1); //Los coeficientes de las variables de n + 1 a n + m son 1
	 
	Matrix cb_1(1,m,1); //Matriz fila (vector fila) de coeficientes de variables basicas de fase 1
	Matrix cn_1(1,n); //Matriz fila (vector fila) de coeficientes de variables no basicas de fase 1
	
	Xb_1 = b; //Solucion basica inicial
	
	double z = (Matrix::matrixProduct(cb_1,Xb_1)).at(0,0); //Valor inicial de la funcion objetivo. Hace el producto del vector de coeficientes de variables basicas por la solucion inicial. 
	//Como la funcion matrixProduct devuelve una matriz, en este caso de dimension 1x1, coge el valor en la posicion (0,0)
	
    printf("Fase I\n");
    
    out = 0; //Codigos de salida: (-1) problema fase 1 infactible, (0) normalidad, (1) optimo, (2) ilimitado, (3) degenerado
	iteration = 0; //Iteracion actual
	
	while(out == 0) {
		iteration++;
		simplexIteration(iteration,n,m,A_1,An_1,B_inv_1,cn_1,cb_1,Xb_1,z,basic_1,nonBasic_1,blandsRule,out); //Ejecuta una iteracion del simplex
	}
	
    if(out == 1) {
		printf("%5sIteracion %4d:%5sOptimo\n", "", iteration, "");
		if(abs(round(z) - z) >= 1e-5) //Puede haber error de tolerancia cuando la funcion objetivo vale 0
			out = -1; //Unfeasible problem
	} else if(out == 2)
		printf("%5sIlimitado%4sIteracion:%4d\n", "", "", iteration);
	else if(out == 3)
		printf("%5sDegenerado%4sIteracion:%4d\n", "", "", iteration);
}

//Realiza la fase 2 del simplex
void phase_2(const int n, const int m, const Matrix& A, const Matrix& b, const Matrix& c, Matrix& Xb, Matrix& B_inv, vector<int>& basic, vector<int>& nonBasic, int& iteration, const bool blandsRule) {
	
	Matrix An(m,1);	//Matriz de coeficientes de variables no basicas en la fase 2
	An.replaceCol(A.getCol(nonBasic[0]-1),0); //Crea la matriz de coeficientes a partir de la matriz A y del vector de variables no basicas
	for(unsigned int i = 1; i < nonBasic.size(); i++)
		An.insertCol(A.getCol(nonBasic[i] - 1), i);	//Crea la matriz de coeficientes a partir de la matriz A y del vector de variables no basicas
	
	Matrix cb = Matrix(1,m); //Matriz fila (vector fila) de variables basicas en fase 2
	for(unsigned int i = 0; i < basic.size(); i++)
		cb.set(0, i, c.at(basic[i]-1, 0));
	
	Matrix cn = Matrix(1,n-m); //Matriz fila (vector fila) de variables no basicas en fase 2
	for(unsigned int i = 0; i < nonBasic.size(); i++)
		cn.set(0,i, c.at(nonBasic[i]-1, 0));

	double z = Matrix::matrixProduct(cb,Xb).at(0,0); //Funcion objetivo de fase 2
	
    printf("Fase II\n");
	int out = 0; //Codigo de salida
	while(out == 0) {
		iteration++;
		simplexIteration(iteration,n,m,A,An,B_inv,cn,cb,Xb,z,basic,nonBasic,blandsRule,out);
	}
    
    if(out == 1) {
		printf("%5sIteracion %4d:%5sOptimo%5sZ = %.3f\n", "", iteration, "", "", z);
	} else if(out == 2)
		printf("%5sIlimitado%4sIteracion:%4d\n", "", "", iteration);
	else if(out == 3)
		printf("%5sDegenerado%4sIteracion:%4d\n", "", "", iteration);
    
}

//Calcula el vector de costes reducidos
extern Matrix computeReducedCosts(const Matrix& cn, const Matrix& cb, const Matrix& B_inv, const Matrix& An, const vector<int>& nonBasic, int& q, int& q_index, bool& optimal, const bool blandsRule) {
	
	Matrix RHS = Matrix::matrixProduct(Matrix::matrixProduct(cb, B_inv), An); //RHS - Right Hand Side, es el producto de (cb)*(B^-1)*(An)
	RHS.scalarProduct(-1); //Multiplica RHS por -1
	
	Matrix Rn = Matrix::matrixSum(cn,RHS); //El vector de costes reducidos es la suma de cn + [-(cb)*(B^-1)*(An)] = cn + RHS
	
	int i_neg = -1; //Indice del coste reducido
	int size = Rn.getCols(); //Tamaño del vector de costes reducidos, es n-m

	for(int i = 0; i < size and i_neg == -1; i++) //Busca en el vector de costes reducidos mientras no encuentre uno negativo
		if(Rn.at(0,i) < 0)
			i_neg = i;
	
	if(i_neg == -1) { //Si no hay ningun coste reducido negativo, la variable i_neg = -1, estamos en el optimo
		optimal = true;
		return Rn;
	}
	
	optimal = false; //No estamos en el optimo
	q = nonBasic[i_neg]; //Subindice de la variable no basica que va a entrar
	q_index = i_neg; //Posicion en el vector de variables no basicas que ocupa q
	
	if(blandsRule) { //Selecciona el coste reducido por regla de bland
		for(int i = i_neg + 1; i < size; i++)
			if(Rn.at(0,i) < 0 and nonBasic[i] < q) {
				q_index = i;
				q = nonBasic[i];
			}
	} else { //Selecciona el coste reducido por coste reducido mas negativo
		for(int i = q_index + 1; i < size; i++)
			if(Rn.at(0,i) < Rn.at(0,q_index)) {
				q_index = i;
				q = nonBasic[i];
			}
	}
		
	return Rn;
}

//Calcula la direccion basicas factible
extern Matrix computeBasicFeasibleDirection(const Matrix& B_inv, const Matrix& Aq, bool& unlimited) {
	
	unlimited = true;
	
	Matrix db = Matrix::matrixProduct(B_inv, Aq); //La direccion basica factible es el producto (B^-1)*(Aq)
	db.scalarProduct(-1); //Multiplica db por -1
	
	for(unsigned int i = 0; i < db.getRows() and unlimited; i++) //Busca en el vector db una componente negativa. Si la encuentra, el problema no es ilimtado
		if(db.at(i,0) < 0)
			unlimited = false;
	
	return db;
}

//Calcula la longitud de paso
extern double computeTheta(const Matrix& db, const Matrix& Xb, int& p) {
	
	double min_length = 1e9; //Inicializa a un valor que con los problemas propuestos no se deberia alcanzar
	
	for(unsigned int i = 0; i < db.getRows(); i++) {
		if(db.at(i,0) < 0) {
			double length = -(Xb.at(i,0)/db.at(i,0));
			if(length < min_length) {
				p = i;
				min_length = length;
			}
		}
	}
	
	/*
	if(min_length == 0)
		cout << "WRONG" << endl;
	*/
	return min_length;
}

//Actualiza las variables
extern void updateVariables(double& z, Matrix& Xb, vector<int>& basic, vector<int>& nonBasic, const double theta, const Matrix& db, const int q, const double rq, const int p) {
	
	z = z + theta * rq; //Actualiza funcion objetivo
	Xb = Matrix::matrixSum(Xb, Matrix::scalarProduct(db,theta)); //Actualiza la SBF actual
	
	Xb.set(p,0,theta); //Actualiza la SBF actual
	
	bool found = false;
	for(unsigned int q_index_1 = 0; q_index_1 < nonBasic.size() and not found; q_index_1++)
		if(nonBasic[q_index_1] == q) { //Busca la posicion en el vector de no basicas de q, tambien podria cambiarlo por la variable q_index que ya esta creada dentro de simplexIteration, pero son las 12 de la noche y me da palo
			nonBasic[q_index_1] = basic[p];
			found = true;
		}
	basic[p] = q;
}

//Actualiza las matrices, para que tanto comentario que nadie se va a leer luego XD
extern void updateMatrices(int m, const Matrix& A, Matrix& B_inv, Matrix& An, Matrix& cb, Matrix& cn, const Matrix& db, const int p, const int Bp, const int q_index, const int q) {
	
	Matrix p_col = A.getMatrixCol(Bp - 1); //Columna en la matriz A de la variable que sale
	Matrix q_col = A.getMatrixCol(q-1); //Columna en la matriz A de la variable que entra
	//Update of An
	An.replaceMatrixCol(p_col, q_index); //En la matriz de coeficientes de variables no basicas, cambia la columna de la variable entrante por la que sale de la base
	
	//Update of B_inv
	vector<double> newCol;	//Columna especial de la matriz identidad, donde cada posicion es -[d_B(i)/d_B(p)], menos la posicion i = p, que es -1/d_B(p)
	double pivot = db.at(p,0);
	for(int i = 0; i < m; i++)
		newCol.push_back(-db.at(i,0)/pivot); 
	newCol[p] = -1/pivot;
	
	Matrix E = Matrix::identity(m);
	E.replaceCol(newCol, p); //Inserta en la identidad la columna especial
	
	B_inv = Matrix::matrixProduct(E,B_inv); //Actualiza la inversa
	
	//Update of cb and cn
	double cb_p = cb.at(0,p);
	cb.set(0,p,cn.at(0,q_index)); //Actualiza el vector de coeficientes de variables basicas
	cn.set(0,q_index,cb_p); //Actualiza el vector de coeficientes de variables no basicas
}

//Busca si hay degeneracion
bool isDegenerate(const Matrix& Xb) {
	
	for(unsigned int i = 0; i < Xb.getRows(); i++)
		if(Xb.at(i,0) == 0)
			return true;
			
	return false;
}
