#include <vector>
#include <string>
#include "Matrix.h"
using namespace std;

extern void printIteration(const int iteration, const int q, const double rq, const int p, const int Bp, const double theta, const int z, const vector<int>& basic, const vector<int>& nonBasic);

extern void simplexIteration(int iteration, int n, int m, const Matrix& A, Matrix& An, Matrix& B_inv, Matrix& cn, Matrix& cb, Matrix& Xb, double& z, vector<int>& basic, vector<int>& nonBasic, const bool blandsRule, int& out);

extern void phase_1(const int n, const int m, const Matrix& A, const Matrix& b, Matrix& Xb, Matrix& B_inv, vector<int>& optimalBasic_1, vector<int>& optimalNonBasic_1, int& iteration, const bool blandsRule, int& out);

extern void phase_2(const int n, const int m, const Matrix& A, const Matrix& b, const Matrix& c, Matrix& Xb, Matrix& B_inv, vector<int>& basic, vector<int>& nonBasic, int& iteration, const bool blandsRule);

extern Matrix computeReducedCosts(const Matrix& cn, const Matrix& cb, const Matrix& B_inv, const Matrix& An, const vector<int>& nonBasic, int& q, int& q_index, bool& optimal, const bool blandsRule);

extern Matrix computeBasicFeasibleDirection(const Matrix& B_inv, const Matrix& Aq, bool& unlimited);

extern double computeTheta(const Matrix& db, const Matrix& Xb, int&);

extern void updateVariables(double& z, Matrix& Xb, vector<int>& basic, vector<int>& nonBasic, const double step, const Matrix& db, const int q, const double rq, const int p);

extern void updateMatrices(int m, const Matrix& A, Matrix& B_inv, Matrix& An, Matrix& cb, Matrix& cn, const Matrix& db, const int p, const int Bp, const int q_index, const int q);
	
extern bool isDegenerate(const Matrix& Xb);

