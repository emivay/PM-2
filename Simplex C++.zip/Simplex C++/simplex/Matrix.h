#ifndef MATRIX_H
#define MATRIX_H

#include <vector>

class Matrix {
private:
	bool built;
	unsigned int rows;
	unsigned int cols;
	std::vector<std::vector<double>> matrix;
public:
	//Constructors
	Matrix();
	Matrix(unsigned int, unsigned int);	//Rows and columns
	Matrix(unsigned int, unsigned int, double); //Rows, columns and a value to fill all the matrix
	Matrix(unsigned int, unsigned int, std::vector<std::vector<double>>); //Rows, columns and a vector of vectors that represents the matrix
	Matrix(std::vector<std::vector<double>>); //A vector of vectors that represents the matrix
	//Getters
	const bool isSingular(void) const; //Returns if determinant is 0 (true) or not (false)
	const bool isBuilt(void) const; //Returns if the object is constructed (true) or not (false)
	const unsigned int getRows(void) const; //Returns number of rows
	const unsigned int getCols(void) const; //Returns numbers of columns
	const std::vector<std::vector<double>> getMatrix(void) const; //Returns the matrix
	const std::vector<double> getRow(unsigned int) const; //Returns a vector representing a row of the matrix
	const Matrix getMatrixRow(unsigned int) const; //Returns a row-matrix which is a row of the matrix
	const std::vector<double> getCol(unsigned int) const; //Returns a vector representing a column of the matrix
	const Matrix getMatrixCol(unsigned int) const; //Returns a column-matrix which is a columns of the matrix
	const double at(unsigned int, unsigned int) const; //Returns the value at a certain row and column
	//Modifiers
	bool eraseRow(unsigned int); //Deletes a row
	bool eraseRows(unsigned int, unsigned int); //Deletes the rows between two specified rows
	bool eraseCol(unsigned int); //Deletes a column
	bool eraseCols(unsigned int, unsigned int); //Deletes the columns between two specified columns
	bool insertRow(std::vector<double>, unsigned int); //Inserts a row in a certain position
	bool replaceRow(std::vector<double>, unsigned int); //Replaces a row by another. The row is given by a vector
	bool replaceMatrixRow(Matrix, unsigned int); //Replaces a row by another. Now the row is given by a row-matrix
	bool insertCol(std::vector<double>, unsigned int); //Inserts a column in a certain position
	bool replaceCol(std::vector<double>, unsigned int);  //Replaces a column by another. The column is given by a vector
	bool replaceMatrixCol(Matrix, unsigned int); //Replaces a column by another. now the column is given by a column-matrix
	bool insertMatrixInRow(Matrix m, unsigned int); //Inserts a matrix of correct dimensions (same number of columns) at a certain position
	bool insertMatrixInCol(Matrix m, unsigned int); //Inserts a matrix of correct dimensions (same number of rows) at a certain position
	void roundMatrix(double); //If the difference of a value of the matrix and the nearest integer is smaller or equal to the specified, the value is specified. This is done for all the values
	void set(unsigned int, unsigned int, double); //Changes a value of the matrix
	bool resize(unsigned int, unsigned int); //Changes the sizes of the matrix
	//Read and print
	void read(void); //Reads a matrix. Never used. Don't know why I implemented this.
	void print(void) const; //Prints the matrix
	void info(void) const; //Shows the dimensions of the matrix and prints it
	//Operations
	void scalarProduct(double); //Multiplies the matrix by a scalar, modifying the matrix in which the values are saved
	double determinant(void) const; //Computes the determinant of the matrix using minors
	static Matrix identity(unsigned int); //Returns the identity matrix of a certain dimension
	static Matrix random(unsigned int, unsigned int, int, int); //Returns a random matrix. Used for tests
	Matrix subMatrix(unsigned int, unsigned int, unsigned int, unsigned int) const; //Returns a submatrix of the matrix. If the arguments are out of bounds, returns null matrix
	static Matrix scalarProduct(Matrix, double); //Returns the product of a matrix (which is not modified) by a scalar
	static Matrix matrixSum(Matrix, Matrix); //Returns the sum of two matrices, not modifying them
	static Matrix matrixProduct(Matrix, Matrix); //Returns the product of two matrices, not modifying them
	static Matrix transpose(Matrix); //Returns the transposed matrix
	static Matrix adjoint(Matrix); //Returns the adjoint matrix
	static Matrix inverse(Matrix); //Returns the inverse matrix.
};

#endif //MATRIX_H
