#include <iostream>
#include <stdio.h>
#include <vector>
#include "Matrix.h"
#include "Simplex.h"
using namespace std;

void read_input(unsigned int&, unsigned int&, Matrix&, Matrix&, Matrix&); //Lee la entrada del programa
void info(const int, const int, const Matrix&, const Matrix&, const Matrix&);

int main(void) {
	
	unsigned int n; //Numero de variables
	unsigned int m; //Numero de restricciones
	Matrix A; //Matriz de coeficientes de variables en las restricciones
	Matrix B_inv; //Matriz inversa
	Matrix b; //Vector de terminos independientes
	Matrix c; //Vector de coeficientes de variables en la funcion objetivo
	Matrix Xb; //Vector de variables basicas
	const bool blandsRule = true; //Si se usa o no la regla de Bland
	
	read_input(n,m,A,b,c); 
	
	vector<int> nonBasic(n); //Vector de variables no basicas
	for(unsigned int i = 0; i < n; i++)
		nonBasic[i] = i + 1; //Prepara el vector para la fase 1
	
	vector<int> basic(m); //Vector de variables basicas
	for(unsigned int i = 0; i < m; i++)
		basic[i] = i + n + 1; //Prepara el vector para la fase 1
	
	int out = 0; //Codigos de salida: (-1) problema fase 1 infactible, (0) normalidad, (1) optimo, (2) ilimitado, (3) degenerado
    int iteration = 0;
    printf("Regla de Bland: %s\n", (blandsRule ? "Si" : "No"));
	phase_1(n, m, A, b, Xb, B_inv, basic, nonBasic, iteration, blandsRule, out); //Ejecuta la fase 1
    
    if(out == 1) { //Si el optimo del problema de fase 1 es Z = 0 (problema de fase 2 factible)
		bool found = false;
		for(unsigned int i = 0; i < basic.size() and not found; i++) //Una variable artificial en la base tras la fase 1. En teoria no debe pasar, segur Javier
			if(basic[i] > (int)n)
				found = true;
		
		if(not found) {	//Si no hay ninguna artificial en la base
			vector<int> nonBasic_2; //Vector de variables no basicas de fase 2
			for(unsigned int i = 0; i < nonBasic.size(); i++)
				if(nonBasic[i] <= (int)n)
					nonBasic_2.push_back(i+1); //Busca las no basicas no artificiales en el vector. Cuando encuentra una, la enchufa en el vector de no basicas para la fase 2
					
			phase_2(n, m, A, b, c, Xb, B_inv, basic, nonBasic_2, iteration, blandsRule); //Ejecuta la fase 2
		} else
			printf("Variable artificial en la base");
		
	} else
		printf("Problema infactible\n");
		
	return 0;
}

//Lee la matriz A y los vectores c y b
void read_input(unsigned int& n, unsigned int& m, Matrix& A, Matrix& b, Matrix& c){
	
	cin >> n >> m;
	A = Matrix(m, n);
	for(unsigned int i = 0; i < m; i++)
		for(unsigned int j = 0; j < n; j++) {
			double x;
			cin >> x;
			A.set(i,j,x);
		}
	
	c = Matrix(n,1);
	for(unsigned int i = 0; i < n; i++) {
		double x;
		cin >> x;
		c.set(i,0,x);
	}
	
	b = Matrix(m,1);
	for(unsigned int i = 0; i < m; i++) {
		double x;
		cin >> x;
		b.set(i,0,x);
	}
}

//No sirve para nada pero hace bonito
void info(const int n, const int m, const Matrix& A, const Matrix& b, const Matrix& c) {
	
	cout << "Variables: " << n << endl;
	cout << "Constrictions: " << m << endl;
	
	cout << "A: " << endl;
	A.print();
	
	cout << endl << "B: " << endl;
	Matrix::transpose(b).print();
	
	cout << endl << "C: " << endl;
	Matrix::transpose(c).print();
	
}


